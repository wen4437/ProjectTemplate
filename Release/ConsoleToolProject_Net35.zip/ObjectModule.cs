﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.My.CommonUtil;

namespace ConsoleToolProjectTemplate
{
    public class CSVInfo
    {
        [Column("ID")]
        public string Id { get; set; }
    }

    public class Config
    {

    }
}
