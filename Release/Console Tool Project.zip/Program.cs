﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.My.CommonUtil;

namespace $safeprojectname$
{
    class Program
    {
        private static Logger log = Logger.CreateLogger(typeof(Program));

        static void Main(string[] args)
        {
            if (args.Length != 1)
            {
                log.Error("Parameters count is not 1.");
                //return;
            }

            try
            {
                Config config = ConfigurationUtil.GetConfiguration<Config>(args[0]);
                //Your Code.
            }
            catch (Exception ex)
            {
                log.Error("An error occurred while execute Main. Exception: {0}", ex.ToString());
            }
            Console.ReadKey();
        }
    }
}
